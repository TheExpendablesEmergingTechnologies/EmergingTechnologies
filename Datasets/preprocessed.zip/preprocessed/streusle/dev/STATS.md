STREUSLE Stats
==============

* Documents:          192
* Sentences:          554
* Tokens:            5394 (excludes ellipsis nodes)
* Unique lemmas:     1310
* [LexCat](LEXCAT.txt)
* [MWEs](MWES.txt)
* [Supersenses](SUPERSENSES.txt)
