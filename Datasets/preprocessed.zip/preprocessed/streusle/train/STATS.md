STREUSLE Stats
==============

* Documents:          347
* Sentences:         2723
* Tokens:           44805 (excludes ellipsis nodes)
* Unique lemmas:     4524
* [LexCat](LEXCAT.txt)
* [MWEs](MWES.txt)
* [Supersenses](SUPERSENSES.txt)
