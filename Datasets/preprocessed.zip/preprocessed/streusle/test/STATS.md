STREUSLE Stats
==============

* Documents:          184
* Sentences:          535
* Tokens:            5381 (excludes ellipsis nodes)
* Unique lemmas:     1275
* [LexCat](LEXCAT.txt)
* [MWEs](MWES.txt)
* [Supersenses](SUPERSENSES.txt)
